//
//  Help.h
//  YesPayCardHolderWallet
//
//  Created by ankit on 12/14/13.
//
//

#import <UIKit/UIKit.h>

@interface Help : UIViewController
@property(strong,nonatomic)IBOutlet UILabel *question1lbl;
@property(strong,nonatomic)IBOutlet UILabel *question2lbl;
@property(strong,nonatomic)IBOutlet UILabel *question3lbl;
@property(strong,nonatomic)IBOutlet UILabel *question4lbl;
@property(strong,nonatomic)IBOutlet UILabel *question5lbl;
@property(strong,nonatomic)IBOutlet UILabel *ans1lbl;
@property(strong,nonatomic)IBOutlet UILabel *ans2lbl;
@property(strong,nonatomic)IBOutlet UILabel *ans3lbl;
@property(strong,nonatomic)IBOutlet UILabel *ans4lbl;
@property(strong,nonatomic)IBOutlet UILabel *ans5lbl;
@property(strong,nonatomic)IBOutlet UILabel *signuplbl;


@end
