//
//  CardDetailsData.m
//  YesPayCardHolderWallet
//
//  Created by Chandra Prakash on 11/05/10.
//  Copyright 2010 InfoBeans. All rights reserved.
//

#import "CardDetailsData.h"


@implementation CardDetailsData
@synthesize cardReferance;
@synthesize cardnumber;
@synthesize cardname;
@synthesize address1;
@synthesize address2;
@synthesize address3;
@synthesize city;
@synthesize postcode;
@synthesize phone1;
@synthesize fax1;
@synthesize email1;
@synthesize issuerName;
@synthesize startdate;
@synthesize expiryDate;
@synthesize cardissuenumber;
@synthesize updatetimeinterval;
@synthesize cardBalance;
@synthesize cardStatus;
@synthesize imageName;
@synthesize fundtransferallowed;
@synthesize cardholdername;
@synthesize country;
@synthesize issuerImageURL;


@end
