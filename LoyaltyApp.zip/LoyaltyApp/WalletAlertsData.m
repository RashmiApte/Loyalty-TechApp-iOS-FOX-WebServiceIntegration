//
//  WalletAlertsData.m
//  YesPayCardHolderWallet
//
//  Created by Nirmal Patidar on 03/06/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WalletAlertsData.h"


@implementation WalletAlertsData
@synthesize message,updateDateTimeStamp;

@end
