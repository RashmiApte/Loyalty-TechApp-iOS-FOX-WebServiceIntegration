//
//  updateDateTimeStampData.m
//  YesPayCardHolderWallet
//
//  Created by Nirmal Patidar on 28/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "updateDateTimeStampData.h"


@implementation updateDateTimeStampData
@synthesize updateDateTime;

@end
