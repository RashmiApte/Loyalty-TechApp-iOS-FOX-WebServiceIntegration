//
//  AddRetailerViewController.h
//  LoyaltyApp
//
//  Created by ankit on 2/27/14.
//
//

#import <UIKit/UIKit.h>

@interface AddRetailerViewController : UIViewController<UIAlertViewDelegate>
{
    UIButton *btndrawerleft;
    
}
@property(strong,nonatomic)IBOutlet UITableView *tableAddretailer;
@property(strong,nonatomic)UIButton *btnSenderView;



@end
