//
//  UserInfoData.m
//  YesPayCardHolderWallet
//
//  Created by Chandra Prakash on 10/05/10.
//  Copyright 2010 InfoBeans. All rights reserved.
//

#import "UserInfoData.h"


@implementation UserInfoData
@synthesize userid;
@synthesize username;
@synthesize password;
@synthesize firstname;
@synthesize middlename;
@synthesize lastname;
@synthesize dob;
@synthesize address1;
@synthesize address2;
@synthesize city;
@synthesize region;
@synthesize country;
@synthesize postcode;
@synthesize mobileno;
@synthesize emailid;
@synthesize sex;
@synthesize updatetimestamp;
@end
