//
//  LoginData.m
//  YesPayCardHolderWallet
//
//  Created by Chandra Prakash on 11/05/10.
//  Copyright 2010 InfoBeans. All rights reserved.
//

#import "LoginData.h"


@implementation LoginData
@synthesize uid;
@synthesize username;
@synthesize password;
@synthesize userid;
@end
