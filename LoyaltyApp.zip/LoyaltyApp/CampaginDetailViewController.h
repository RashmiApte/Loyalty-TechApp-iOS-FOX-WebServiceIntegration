//
//  CampaginDetailViewController.h
//  LoyaltyApp
//
//  Created by ankit on 2/28/14.
//
//

#import <UIKit/UIKit.h>

@interface CampaginDetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)IBOutlet UITableView *tablecampagindetail;
@end
