//
//  updateDateTimeStampData.h
//  YesPayCardHolderWallet
//
//  Created by Nirmal Patidar on 28/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface updateDateTimeStampData : NSObject {
	NSString *updateDateTime;
}
@property (nonatomic,strong) NSString *updateDateTime;
@end