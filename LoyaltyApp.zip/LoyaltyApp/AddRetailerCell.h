//
//  AddRetailerCell.h
//  LoyaltyApp
//
//  Created by ankit on 3/3/14.
//
//

#import <UIKit/UIKit.h>

@interface AddRetailerCell : UITableViewCell
@property(strong,nonatomic)UIImageView *imgRetiler;
@property(strong,nonatomic)UILabel *lblRetailername;
@property(strong,nonatomic)UIButton *btnAddRetailer;

//@property(strong,nonatomic)UILabel



@end
